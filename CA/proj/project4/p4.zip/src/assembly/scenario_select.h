//
// Created by guestsh1 on 24-4-19.
//

#ifndef SCENARIO_SELECT_H   
#define SCENARIO_SELECT_H

int scenario_select(int current_scenario);

#endif //SCENARIO_SELECT_H