#include "game.h"
#include "lcd/lcd.h"
#include "utils.h"

#define MAX_BULLETS 512
#include <math.h> // for sqrt
#define DEBOUNCE_MS 500
#define DEBOUNCE_CYCLES ((1 / SystemCoreClock) / 1000 * DEBOUNCE_MS)

// Forward declarations for functions defined later in this file

Bullet bullets[MAX_BULLETS];
Player player;
Enemy enemy[2];
int bullet_count = 0;
int last_press_time[6] = {0};       // 用于防抖动3,1,2,4,5
uint16_t framebuffer[LCD_H][LCD_W]; // 行优先或列优先视 LCD 控制器而定

void fb_draw_rect(int x0, int y0, int x1, int y1, uint16_t color)
{
    for (int y = y0; y < y1; y++)
    {
        for (int x = x0; x < x1; x++)
        {
            if (x >= 0 && x < LCD_W && y >= 0 && y < LCD_H)
                framebuffer[y][x] = color;
        }
    }
}

void fb_clear(uint16_t color)
{
    for (int y = 0; y < LCD_H; y++)
        for (int x = 0; x < LCD_W; x++)
            framebuffer[y][x] = color;
}
int Get_Button_Debounced(int key)
{

    uint64_t now = get_timer_value();

    // 这里用你的原始按键读取接口，比如 Get_Button(key) 返回0/1
    int pressed = Get_Button(key);

    if (pressed)
    {
        if (now - last_press_time[key] >= DEBOUNCE_CYCLES)
        {
            last_press_time[key] = now;
            return 1; // 按键触发（防抖通过）
        }
        else
        {
            return 0; // 冷却中，不触发
        }
    }
    else
    {
        return 0; // 未按下，不触发
    }
}

void draw_clear_rect(int x, int y, int w, int h)
{
    LCD_Fill(x, y, x + w, y + h, BLACK); // 用填充矩形清除
}

void draw_show_fps()
{
    static uint64_t last = 0;
    static int frame = 0;
    static float fps = 0.0f;
    frame++;
    uint64_t now = get_timer_value();

    if (now - last >= 1 / SystemCoreClock / 8) // 0/125秒周期
    {
        fps = frame / ((float)(now - last) / (float)SystemCoreClock);
        frame = 0;
        last = now;
    }
    LCD_ShowString(1, 60, (u8 *)"FPS:", WHITE);
    LCD_ShowNum(40, 60, (int)fps, 3, RED);
}

void draw_show_bullet_count(Bullet *pool, int max)
{

    LCD_ShowString(70, 60, (u8 *)"Bullet:", WHITE);
    LCD_ShowNum(125, 60, bullet_count, 3, BLUE);
}

void bullet_spawn(Bullet *pool, int max, float x, float y, float vx, float vy, float speed, int homing)
{
    for (int i = 0; i < max; i++)
    {

        if (!pool[i].alive)
        {
            pool[i].x = x;
            pool[i].y = y;
            pool[i].vx = vx;
            pool[i].vy = vy;
            pool[i].speed = speed;
            pool[i].alive = 1;
            pool[i].homing = homing;
            bullet_count++;
            break;
        }
    }
}
void player_init(Player *p)
{
    p->x = 70;
    p->y = 40;
    p->width = 12;
    p->height = 12;
}

void player_update(Player *player, float dt, Bullet *pool, int max)
{
    player->last_x = player->x;
    player->last_y = player->y;
    if (Get_Button_Debounced(JOY_UP))
        player->y -= 5;
    if (Get_Button_Debounced(JOY_DOWN))
        player->y += 5;
    if (Get_Button_Debounced(JOY_LEFT))
        player->x -= 5;
    if (Get_Button_Debounced(JOY_RIGHT))
        player->x += 5;
    if (Get_Button_Debounced(BUTTON_1))
    {
        bullet_spawn(pool, max, player->x, player->y, 0, -1, 100.0f, 0);
    }
    if (player->x < 0)
        player->x = 0;
    if (player->x + player->width > LCD_W)
        player->x = LCD_W - player->width;
    if (player->y < 0)
        player->y = 0;
    if (player->y + player->height > 50)
        player->y = 50 - player->height;
}

void player_render(Player *p)
{
    LCD_DrawCircle(p->x + p->width / 2, p->y + p->height / 2, p->width / 2, BLUE);
}

void enemy_init(Enemy *e)
{

    e[0].x = 110;
    e[0].y = 40;
    e[0].width = 12;
    e[0].height = 12;
    e[0].shoot_timer = 0;
    e[1].x = 30;
    e[1].y = 40;
    e[1].width = 12;
    e[1].height = 12;
    e[1].shoot_timer = 0;
}

void enemy_update(Enemy *e, float dt, Bullet *pool, int max)
{
    for (int i = 0; i < 2; i++)
    {
        e[i].last_x = e[i].x;
        e[i].last_y = e[i].y;
        e[i].shoot_timer += dt;
        if (e[i].shoot_timer > 0.5f)
        {
            bullet_spawn(pool, max, e[i].x + 3, e[i].y + 6, 0, 1, 100.0f, 1);
            e->shoot_timer = 0;
        }
        e[i].x += 1;
        if (e[i].x > LCD_W)
            e[i].x = 0;
    }
}

void enemy_render(Enemy *e)
{

    LCD_DrawCircle(e[0].x + e->width / 2, e[0].y + e->height / 2, e->width / 2, RED);
    LCD_DrawCircle(e[1].x + e->width / 2, e[1].y + e->height / 2, e->width / 2, RED);
}

void bullet_init_pool(Bullet *pool, int max)
{
    for (int i = 0; i < max; i++)
        pool[i].alive = 0;
}

void bullet_update(Bullet *bullet, Player *player, Enemy *enemy, float dt)
{
    if (!bullet->alive)
        return;
    bullet->last_x = bullet->x;
    bullet->last_y = bullet->y;
    if (bullet->homing)
    {
        float dx = player->x - bullet->x;
        float dy = player->y - bullet->y;
        float dist = sqrt(dx * dx + dy * dy);
        bullet->vx = (dx / dist) * bullet->speed;
        bullet->vy = (dy / dist) * bullet->speed;
    }
    else
    {
        float dx = enemy[0].x - bullet->x;
        float dy = enemy[0].y - bullet->y;
        float dist = sqrt(dx * dx + dy * dy);
        bullet->vx = (dx / dist) * bullet->speed;
        bullet->vy = (dy / dist) * bullet->speed;
    }
    bullet->x += bullet->vx * dt;
    bullet->y += bullet->vy * dt;
    if (bullet->x <= 0 || bullet->x >= LCD_W || bullet->y <= 0 || bullet->y >= 50)
    {
        bullet->alive = 0;
        bullet_count--;
    }
}

void bullet_render(Bullet *pool)
{
    for (int i = 0; i < MAX_BULLETS; i++)
    {
        if (pool[i].alive)
        {
            LCD_DrawPoint((int)pool[i].x, (int)pool[i].y, WHITE);
        }
    }
}

void game_init()
{
    LCD_Clear(BLACK);
    player_init(&player);
    enemy_init(enemy);
    bullet_init_pool(bullets, MAX_BULLETS);
}

void game_update(float dt)
{
    player_update(&player, dt, bullets, MAX_BULLETS);
    enemy_update(enemy, dt, bullets, MAX_BULLETS);
    for (int i = 0; i < MAX_BULLETS; i++)
    {
        if (bullets[i].alive)
        {
            bullet_update(&bullets[i], &player, enemy, dt);
        }
    }
    game_render(); // 局部刷新屏幕
}
void game_render()
{
    draw_clear_rect(player.last_x, player.last_y, player.width, player.height);
    draw_clear_rect(enemy[0].last_x, enemy[0].last_y, enemy[0].width, enemy[0].height);
    draw_clear_rect(enemy[1].last_x, enemy[1].last_y, enemy[1].width, enemy[1].height);
    for (int i = 0; i < MAX_BULLETS; i++)
    {

        LCD_DrawPoint((int)bullets[i].last_x, (int)bullets[i].last_y, BLACK); // 清除旧点
    }

    for (int i = 0; i < MAX_BULLETS; i++)
    {
        if (bullets[i].alive)
        {
            LCD_DrawPoint((int)bullets[i].x, (int)bullets[i].y, WHITE); // 画新点
        }
    }
    player_render(&player);
    enemy_render(enemy);
    draw_show_fps();
    draw_show_bullet_count(bullets, MAX_BULLETS);
}
